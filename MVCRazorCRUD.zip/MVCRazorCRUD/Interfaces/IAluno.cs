﻿using MVCRazorCRUD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCRazorCRUD.Interfaces
{
    interface IAluno
    {
        Aluno CadastroAluno(Aluno aluno);
        List<Aluno> ListarAluno();
        List<Aluno> BuscarPorID(int id);
        void RemoverAluno(int Id);
        void AtualizarAluno(Aluno aluno);
    }
}
