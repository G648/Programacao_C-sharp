﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCRazorCRUD.Models
{
    public class ProfessoresBase
    {
        public int ProfessorId { get; set; }
        public string ProfessorNome { get; set; }
        public string ProfessorEmail { get; set; }
        public string ProfessorEndereco { get; set; }
        public string ProfessorTelefone { get; set; }
        public string ProfessoresCargo { get; set; }

    }
}
